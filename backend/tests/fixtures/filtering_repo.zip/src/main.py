print("indexed")
