raise RuntimeError("must be ignored by repository .gitignore")
