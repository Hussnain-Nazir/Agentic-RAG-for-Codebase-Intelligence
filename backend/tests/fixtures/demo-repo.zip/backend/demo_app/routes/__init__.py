"""Demo HTTP routes."""
