"""Demo application package."""
